package com.study.customer;


import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;


import java.util.List;

@Controller
@RequestMapping("test")
public class TestController {

    @Autowired
    private DiscoveryClient discoveryClient;

    @RequestMapping("testV1")
    @ResponseBody
    public String testorderEureka()throws Exception{
//        List<ServiceInstance> instanceList = discoveryClient.getInstances(serviceId:"order");

        List<ServiceInstance> instanceList = discoveryClient.getInstances("order");

        ServiceInstance serviceInstance = instanceList.get(0);
        int port = serviceInstance.getPort();
        String host = serviceInstance.getHost();
        String url = "http://"+host+":"+port+"/order/create?name=zhangs";
        HttpClient httpClient = new DefaultHttpClient();
        HttpPost httpPost = new HttpPost(url);
        HttpResponse  httpResponse = httpClient.execute(httpPost);
        String str = "";
        if(httpResponse.getStatusLine().getStatusCode() ==200){
            str = EntityUtils.toString(httpResponse.getEntity());
        }
        return str;
    }
    @Bean
    @LoadBalanced // 负载均衡

    public RestTemplate restTemplate(){
        return new RestTemplate();
    }
    @Autowired
    private  RestTemplate restTemplate;
    @RequestMapping("testV2")
    @ResponseBody
    public String testorderRest()throws Exception{
        return  restTemplate.getForObject("http://order/order/create?name=lzt",String.class,"");
    }

}
