package com.study.eurakaserver.config;

import com.netflix.appinfo.InstanceInfo;
import com.study.eurakaserver.utils.DateUtils;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.netflix.eureka.server.event.*;
import org.springframework.context.event.EventListener;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * @author lizhaoteng
 * @date 2018/9/12
 **/
@Component
@RequiredArgsConstructor
@Slf4j
public class EurekaStateChangeListener {
    @NonNull
    private JavaMailSender javaMailSender;
    @EventListener
    public void listen(EurekaInstanceCanceledEvent eurekaInstanceCanceledEvent) {
        //服务断线事件
        String appName = eurekaInstanceCanceledEvent.getAppName();
        String serverId = eurekaInstanceCanceledEvent.getServerId();
        long timestamp = eurekaInstanceCanceledEvent.getTimestamp();
        System.out.println(timestamp);
        System.out.println(appName);
        System.out.println(serverId);
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom("466249203@qq.com");
        message.setTo("jiemenchao@163.com");
        message.setSubject("服务停止："+eurekaInstanceCanceledEvent.getAppName()+"服务:"+serverId);
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        long now = System.currentTimeMillis();
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(now);
        message.setText("时间 " + formatter.format(calendar.getTime()));

        try {
            javaMailSender.send(message);
        } catch (Exception e) {
            log.error("发送错误!");
            e.printStackTrace();
        }
    }
    @EventListener
    public void listen(EurekaInstanceRegisteredEvent event) {
        InstanceInfo instanceInfo = event.getInstanceInfo();
        System.out.println(instanceInfo.getAppName()+"进行注册");
    }

    @EventListener
    public void listen(EurekaInstanceRenewedEvent event) {
        System.out.println(event.getServerId()+"\t"+event.getAppName()+"服务续约");
    }

    @EventListener
    public void listen(EurekaRegistryAvailableEvent event) {
        System.out.println("注册中心 启动");
    }

    @EventListener
    public void listen(EurekaServerStartedEvent event) {
        //Server启动
        System.out.println("Eureka Server 启动");
    }

}
