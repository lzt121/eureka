package com.study.eurakaserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;
import org.springframework.context.annotation.ComponentScan;

/**
 * @author lizhaoteng
 */
@SpringBootApplication
@EnableEurekaServer
public class EurakaserverApplication {

    public static void main(String[] args) {
        SpringApplication.run(EurakaserverApplication.class, args);
    }
}
