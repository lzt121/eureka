package com.study.eurakaserver.config;

import lombok.Data;

import java.net.Authenticator;

/**
 * @author lizhaoteng
 * @date 2018/9/12
 **/
@Data
public class MailAuthenticator extends Authenticator {
    private String user;
    private String pwd;
    public MailAuthenticator(String user, String pwd) {
        this.user = user;
        this.pwd = pwd;
    }


}
