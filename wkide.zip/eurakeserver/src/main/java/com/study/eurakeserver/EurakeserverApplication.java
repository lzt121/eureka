package com.study.eurakeserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class EurakeserverApplication {

    public static void main(String[] args) {
        SpringApplication.run(EurakeserverApplication.class, args);
    }
}
